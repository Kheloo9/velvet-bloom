#!/bin/sh
# Local run (creates venv + DB on first use)
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
.venv/bin/pip install -q -r requirements.txt
.venv/bin/python app.py
